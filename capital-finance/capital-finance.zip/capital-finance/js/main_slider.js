$(document).ready(function(){
    $(".owl-carousel").owlCarousel(

        {
            loop:true,
            margin:0,
            nav:true,
            navText : ["",""],
            dots:false,
            items: 1,
            autoplay:true,
            autoplayTimeout:3000,
            autoplayHoverPause:true
        }

    );
});